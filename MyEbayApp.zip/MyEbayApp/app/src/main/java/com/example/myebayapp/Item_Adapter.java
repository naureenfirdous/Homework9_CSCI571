package com.example.myebayapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class Item_Adapter extends RecyclerView.Adapter<Item_Adapter.ItemViewHolder> {

    private ArrayList<ItemDetails> m_item_list;
    private Context context;
    public Item_Adapter(Context context, ArrayList <ItemDetails> item_list) {
            this.m_item_list = item_list;
            this.context     = context;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_details,parent,false);
        ItemViewHolder ivh = new ItemViewHolder(v);
        return ivh;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        ItemDetails currentItem = m_item_list.get(position);

        String imageURI = currentItem.getItem_image();
        //System.out.println(imageURI);
        if(imageURI.equals("https://thumbs1.ebaystatic.com/pict/04040_0.jpg")) {
            Picasso.with(context).load(R.drawable.ebay_default).into(holder.mImageView);
        }
        else {
            Picasso.with(context).load(imageURI).into(holder.mImageView);
        }
        String listing = currentItem.getTopRatedListing();
        if(listing.matches("")) {
            holder.listing.setText("");
        }
        else {
            holder.listing.setText(Html.fromHtml(listing));
        }

        holder.title.setText(currentItem.getItem_title());
        holder.condition.setText(Html.fromHtml(currentItem.getItem_condition()));
        holder.shipping.setText(Html.fromHtml(currentItem.getShippingInfo()));
        holder.price.setText(Html.fromHtml(currentItem.getCurrentPrice()));

        String item_id = currentItem.getItemid();
        final Bundle bundle  = new Bundle();
        bundle.putString("item_id",item_id);
        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                System.out.println("Card view clicked");
                Intent intent = new Intent(v.getContext(), MainActivity2.class);
                intent.putExtras(bundle);
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return m_item_list.size();
    }

    public static class ItemViewHolder extends  RecyclerView.ViewHolder {

        public View view;
        public ImageView mImageView;
        public TextView title;
        public TextView condition;
        public TextView shipping;
        public TextView price;
        public TextView listing;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            mImageView = itemView.findViewById(R.id.item_image);
            title = itemView.findViewById(R.id.item_title);
            condition = itemView.findViewById(R.id.item_condition);
            shipping = itemView.findViewById(R.id.item_shipping);
            price    = itemView.findViewById(R.id.item_price);
            listing = itemView.findViewById(R.id.item_listing);
        }
    }
}
