package com.example.myebayapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class Activity_Product_Catalog extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RequestQueue mQueue;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<ItemDetails> items_list;
    private String keyword = "";
    private String sortOrder;
    private Integer min_price;
    private Integer max_price;
    private Boolean isNew;
    private Boolean isUsed;
    private Boolean isUnspecified;
    private ProgressBar spinner;
    private TextView text_progress;
    private TextView no_records;
    private String results;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__product__catalog);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        spinner = (ProgressBar) findViewById(R.id.progressBar1);
        spinner.setVisibility(View.VISIBLE);

        text_progress = (TextView) findViewById(R.id.progressBar2);
        text_progress.setVisibility(View.VISIBLE);

        no_records = findViewById(R.id.no_records);
        no_records.setVisibility(View.GONE);

        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setVisibility(View.GONE);

        Bundle bundle     = getIntent().getExtras();
        keyword           = bundle.getString("keyword");
        sortOrder         = bundle.getString("SortOrder");
        min_price         = bundle.getInt("min_price");
        max_price         = bundle.getInt("max_price");
        if(min_price == 0) {
            min_price = null;
        }
        if(max_price == 0) {
            max_price = null;
        }
        System.out.println(min_price);
        System.out.println(max_price);
        isNew     = bundle.getBoolean("isNew");
        isUsed    = bundle.getBoolean("isUsed");
        isUnspecified = bundle.getBoolean("isUnspecified");
        System.out.println("Reached second activity");

        // Calling the view here
        items_list = new ArrayList<ItemDetails>();
        System.out.println("Calling the view now");
        callRecyclerView(items_list);
        jsonParse(keyword,sortOrder,min_price,max_price,isNew,isUsed,isUnspecified);

        // Setting the swipe refresh listener
        mSwipeRefreshLayout = findViewById(R.id.refresh);
        mSwipeRefreshLayout.setOnRefreshListener(this);

    }

    private void jsonParse(final String keyword, String sortOrder, Integer min_price, Integer max_price, Boolean isNew, Boolean isUsed, Boolean isUnspecified) {

        spinner = (ProgressBar) findViewById(R.id.progressBar1);
        mRecyclerView = findViewById(R.id.recyclerView);
        text_progress = findViewById(R.id.progressBar2);
        no_records = findViewById(R.id.no_records);


        final String url = "https://csci571-homework9.wl.r.appspot.com/search?keywords="+keyword+"&min_price="+min_price+"&max_price="+max_price+"&new="+isNew+"&used="+isUsed+"&unspecified="+isUnspecified+"&SortOrder="+sortOrder;
        System.out.println("Reached jsonParse method");
        System.out.println(url);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("items");

                            for(int i=0;i<jsonArray.length();i++) {
                                JSONObject item = jsonArray.getJSONObject(i);
                                String itemId = item.getString("itemid");
                                String title = item.getString("title");
                                String image = item.getString("galleryURL");
                                String condition = item.getString("conditionDisplayName");
                                Integer shipping = item.getInt("shippingCost");
                                Double price = item.getDouble("currentPrice");
                                Boolean topRatedListing = item.getBoolean("topRatedListing");
                                items_list.add(new ItemDetails(image,title,condition,price,shipping,topRatedListing,itemId));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        System.out.println("Data Set Changed");
                        System.out.println(items_list.size());
                        spinner.setVisibility(View.GONE);
                        text_progress.setVisibility(View.GONE);
                        if(items_list.size() == 0) {
                            // Displaying Error Message ' No Records found message
                            mRecyclerView.setVisibility(View.GONE);
                            no_records.setVisibility(View.VISIBLE);
                            makeToast();
                        }
                        else {
                            mRecyclerView.setVisibility(View.VISIBLE);
                            mAdapter.notifyDataSetChanged();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                spinner.setVisibility(View.GONE);
                text_progress.setVisibility(View.GONE);

            }
        });

        // Adding the request to the queue ----
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        mQueue = Volley.newRequestQueue(this);
        mQueue.add(request);


    }

    private void makeToast() {
        System.out.println("Error Message");
        Toast.makeText(this, "No Records", Toast.LENGTH_SHORT).show();
    }

    private void callRecyclerView(ArrayList<ItemDetails> items_list) {
        // Creating the recycler view here ----
        System.out.println("Calling the recycler view");
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new GridLayoutManager(this,2);
        mAdapter = new Item_Adapter(getApplicationContext(), items_list);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

    }

    @Override
    public void onRefresh() {
        items_list = new ArrayList<ItemDetails>();
        callRecyclerView(items_list);
        jsonParse(keyword,sortOrder,min_price,max_price,isNew,isUsed,isUnspecified);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mSwipeRefreshLayout.setRefreshing(false);
            }
        }, 2000);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // app icon in action bar clicked; goto parent activity.
                onBackPressed();
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
