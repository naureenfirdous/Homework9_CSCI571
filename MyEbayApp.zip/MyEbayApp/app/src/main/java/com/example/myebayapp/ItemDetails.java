package com.example.myebayapp;

import android.net.Uri;

public class ItemDetails {
    private String item_image;
    private String item_title;
    private String item_condition;
    private Double item_price;
    private Integer item_shipping;
    private String shippingInfo;
    private String topRatedListing;
    private String currentPrice;
    private String itemid;

    public ItemDetails(String image,String title,String condition, Double price, Integer shipping, Boolean listing, String ID) {
        item_image = image;
        item_title = title;
        item_price = price;
        item_shipping = shipping;
        itemid = ID;
        currentPrice = "<b>$" + String.valueOf(price) + "</b>";


        // Shipping Criteria
        if(shipping == 0) {
            shippingInfo = "<b>FREE</b> Shipping";
        }
        else {
            shippingInfo = "Ships for $<b>"+shipping+"</b>";
        }

        // condition criteria
        if(condition.matches("")) {
            item_condition = "<b>N/A</b>";
        }
        else {
            item_condition = "<b><i>"+condition+"</i></b>";
        }

        if(listing == true) {
            topRatedListing = "<b>Top Rated Listing</b>";
        }
        else {
            topRatedListing = "";
        }
    }

    public String getItem_image() {
        return item_image;
    }

    public  String getItem_title() {
        return  item_title;
    }

    public  String getItem_condition() {
        return item_condition;
    }

    public String getTopRatedListing() { return topRatedListing; }

    public String getShippingInfo() {
        return shippingInfo;
    }

    public String getCurrentPrice() { return currentPrice; }

    public String getItemid() { return itemid; }
}
