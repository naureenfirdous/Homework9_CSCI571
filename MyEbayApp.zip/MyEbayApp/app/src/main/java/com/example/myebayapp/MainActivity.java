package com.example.myebayapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class MainActivity extends AppCompatActivity implements OnItemSelectedListener{
    String item;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = (Spinner) findViewById(R.id.spinner);
        // Spinner click listener
        spinner.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("Best Match");
        categories.add("Price : highest first");
        categories.add("Price + Shipping : lowest first");
        categories.add("Price + Shipping : highest first");
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
       item = parent.getItemAtPosition(position).toString();
    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    public void btn_submit(View view) {
        if(view.getId() == R.id.submit){
            // Validating the form entered values
            System.out.println("Reached inside the submit method");

            // Resetting the error warnings
            TextView keyword_error = (TextView) findViewById(R.id.keyword_error);
            keyword_error.setVisibility(View.INVISIBLE);
            TextView price_error = (TextView) findViewById(R.id.price_error);
            price_error.setVisibility(View.INVISIBLE);

            EditText keyword_ = findViewById(R.id.keyword);
            EditText min_price_ = findViewById(R.id.min_price);
            EditText max_price_ =  findViewById(R.id.max_price);
            Integer min_price = null;
            Integer max_price = null;

            String keyword = keyword_.getText().toString();
            String to = min_price_.getText().toString();
            String from = max_price_.getText().toString();
            Integer flag = 0;
            String sortOrder = "BestMatch";

            if(keyword.matches("")) {
                Toast.makeText(this, "Please fix all fields with errors", Toast.LENGTH_SHORT).show();
                keyword_error.setVisibility(View.VISIBLE);
                flag = 1;
            }

            if(!to.matches("")) {
                min_price = Integer.parseInt(to);
            }

            if(!from.matches("")) {
                max_price = Integer.parseInt(from);

            }

            if(min_price != null && max_price != null && min_price >= max_price)
            {
                Toast.makeText(this, "Please fix all fields with errors", Toast.LENGTH_SHORT).show();
                price_error.setVisibility(View.VISIBLE);
                flag = 1;
            }

            if(flag == 1) {
                return;
            }

            CheckBox new_ = (CheckBox) findViewById(R.id.new_);
            boolean isNew = new_.isChecked();
            CheckBox used = (CheckBox) findViewById(R.id.used);
            boolean isUsed = used.isChecked();
            CheckBox unspecified = (CheckBox) findViewById(R.id.unspecified);
            boolean isUnspecified = unspecified.isChecked();


            // Creating a bundle to pass the parameters
            Bundle bundle = new Bundle();

            //Add your data to bundle
            bundle.putString("keyword", keyword);

            if(min_price != null) {
                bundle.putInt("min_price", min_price);
            }
            if(max_price != null) {
                bundle.putInt("max_price", max_price);
            }

            
            if(item == "Best Match")
            {
                sortOrder = "BestMatch";
            }
            else if(item == "Price : highest first")
            {
                sortOrder = "CurrentPriceHighest";
            }
            else if(item == "Price + Shipping : lowest first")
            {
                sortOrder = "PricePlusShippingLowest";
            }
            else if(item  == "Price + Shipping : highest first")
            {
                sortOrder = "PricePlusShippingHighest";
            }


            bundle.putString("SortOrder",sortOrder);
            bundle.putBoolean("New",isNew);
            bundle.putBoolean("Used",isUsed);
            bundle.putBoolean("Unspecified",isUnspecified);

            // Opening the product catalog activity.
            openProductCatalog(bundle);

        }
    }

    public void openProductCatalog(Bundle bundle) {
        Intent intent = new Intent(this, Activity_Product_Catalog.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void btn_clear(View view) {
        System.out.println("Reached inside clear method");
        EditText keyword_    = findViewById(R.id.keyword);
        EditText min_price_  = findViewById(R.id.min_price);
        EditText max_price_  =  findViewById(R.id.max_price);
        CheckBox new_        = (CheckBox) findViewById(R.id.new_);
        CheckBox used        = (CheckBox) findViewById(R.id.used);
        CheckBox unspecified = (CheckBox) findViewById(R.id.unspecified);

        // Setting default values on clear
        new_.setChecked(false);
        used.setChecked(false);
        unspecified.setChecked(false);
        keyword_.setText("");
        min_price_.setText("");
        max_price_.setText("");
        spinner.setSelection(0);

        // clearing the warnings
        TextView k_error = (TextView) findViewById(R.id.keyword_error);
        k_error.setVisibility(View.INVISIBLE);

        // clearing the warnings
        TextView p_error = (TextView) findViewById(R.id.price_error);
        p_error.setVisibility(View.INVISIBLE);

    }
}